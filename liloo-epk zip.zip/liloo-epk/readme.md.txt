# Liloo — Amour Létal · EPK (Next.js + Tailwind)

## 🚀 Lancer en local
```bash
npm i
npm run dev
